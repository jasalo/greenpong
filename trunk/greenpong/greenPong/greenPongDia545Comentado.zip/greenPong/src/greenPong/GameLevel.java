/**
 * 
 */
package greenPong;

/**
 * @author ubuntu
 *
 */
public class GameLevel {

}
